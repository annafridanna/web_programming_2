	const students_arr = [
				{
                first_name: "Marry",
                last_name: "Kim",
                age: 18,
                grade: 5.0,	
                },
                {
                first_name: "Dima",
                last_name: "Rudkevich",
                age: 19,
                grade: 6.2,
                },
                {
                first_name: "Lory",
                last_name: 'Verd',
                age: 18,
                grade: 8.7,
                },
                {
                first_name: "Laura",
                last_name: "Jeckson",
                age: 20,
                grade: 5.5,	
                },
			];	

		const form = document.querySelector('#form');
		const module_function = (function () {

			const students = [];
			let table;

		function create_student(first_name, last_name, age, grade) {
			this.first_name = first_name;
			this.last_name = last_name;
			this.age = age;
			this.grade = grade;
		}

		function add_new_student(first_name, last_name, age, grade) {
			const object_student = new create_student(first_name, last_name, age, grade)
			students.push(object_student);
			if (students.length === 1) {
				table = document.createElement('table');
				const row = document.createElement('tr');
				const firstTrTableHTML = `
				<td>first_name</td>
				<td>last_name</td>
				<td>age</td>
				<td>grade</td>
				<td></td>`;
				row.insertAdjacentHTML('beforeend', firstTrTableHTML);
				table.appendChild(row);
			}
			description_for_new_student();
			grade_average();
		}
		function add_column() {
			const student = students[students.length - 1];
			const row = document.createElement('tr');
			const NextOneTrTableHTML = 
			`<td>${ student.first_name }</td>
			 <td>${ student.last_name }</td>
			 <td>${ student.age }</td>
			 <td>${ student.grade }</td>`;
			row.insertAdjacentHTML('beforeend', NextOneTrTableHTML)
			table.appendChild(row);

			document.body.appendChild(table);
		}

		function description_for_new_student() {
			const object_student = students[students.length - 1];
			const row = document.createElement('tr');
			for(let prop in object_student) {
				const column = document.createElement('td');
				column.textContent = object_student[prop];
				row.appendChild(column);
			}
			const delete_studentButton = document.createElement('td');
			delete_studentButton.textContent = 'Delete';
			row.appendChild(delete_studentButton);
			table.appendChild(row);
			document.body.appendChild(table);
		}

		function grade_average() {
			const element = document.querySelector('table');
			element.addEventListener('click', delete_student);
			const resultEl = document.querySelector('#result');
			let avg = 0;
			students.forEach(item => {
				avg += +item.grade;
			});

			resultEl.textContent = +(avg / students.length).toFixed(2);
		}


		function delete_student(event) {
			if (event.target.closest('tr') && event.target.textContent === 'Delete') {
				const deletedElement = event.target.closest('tr');
				Array.from(table.children).forEach((child, index) => {
					if (child === deletedElement) {
						students.splice(index - 1, 1);
						deletedElement.remove();
					}
				})
			}
		}

		return {add_new_student};
})();


		students_arr.forEach( student => {
					module_function.add_new_student(student.first_name, student.last_name, student.age, student.grade);
		});

		form.addEventListener('submit', event => {
			event.preventDefault();
			const first_name = form.first_name.value.trim();
			const last_name = form.last_name.value.trim();
			const age = form.age.value.trim();
			const grade = form.grade.value.trim();
			if (!first_name || !last_name || !age || !grade) {
				console.log('erro');
				return;
			}
			module_function.add_new_student(first_name, last_name, age, grade);
			form.reset();
});
			module_function.add_new_student('Daria', 'Benk', 19,9.5);
			module_function.add_new_student('Kristina', 'Nesterenko', 19,10.0);	