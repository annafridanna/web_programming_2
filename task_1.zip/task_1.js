let num=[];
let k=6,
	sum=0;
for(var i=0; i<k; i++) {
	let z = prompt("Enter number " + Number(i+1) +' : ');
	if(isNaN(z)){
	 	z= prompt("Enter number AGAIN " + Number(i+1) +' : ');
	 }
	 num.push(z);  
	 
	 sum+=Number(z);
}
var r = parseInt(num);   
console.log("array: ",num); 
console.log("array sum: ",sum); 

var min=num[0],
    max=num[0];
for(var i=0; i<k; i++) {
	if(num[i]<min) min=num[i];	 
	if(num[i]>max) max=num[i];    	
}
console.log('min=%s ' + 'max=%s ', min, max);
for (var i=0; i<k; i++) {
	sum += Number(num[i]);
	for (var j=i; j>0; j--) {
		if (num[j] <= num[j-1]) {
			var t=num[j];
			num[j]=num[j-1];
			num[j-1]=t;
		}			
	}
}
console.log(num);